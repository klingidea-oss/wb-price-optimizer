# 🚀 Инструкция по замене приложения WB Price Optimizer V2.0

## 📦 Содержимое архива

```
WB_PRICE_OPTIMIZER_V2_COMPLETE/
├── main.py                          # Backend приложение (26 KB)
├── requirements.txt                  # Python зависимости
├── templates/
│   └── index.html                   # Главная страница (3.7 KB)
├── static/
│   ├── css/
│   │   └── styles.css               # Стили (7.4 KB)
│   └── js/
│       └── app.js                   # Клиентская логика (13.7 KB)
├── load_excel_to_system.py          # Скрипт загрузки Excel
├── category_knowledge_base.json      # База знаний (40 KB, 5,425 товаров)
├── README_FINAL.md                  # Полная документация
└── DEPLOYMENT_INSTRUCTIONS.md        # Эта инструкция
```

---

## 🎯 Ключевые возможности V2.0

### ✨ Новые функции
1. **Анализ эластичности спроса** - расчёт чувствительности продаж к изменению цены
2. **ТОП-20 конкурентов** - только самые продаваемые товары в категории
3. **Сезонность** - учёт трендов из MPStat/WB API (±5% цены)
4. **Excel экспорт** - полный отчёт с 15 колонками данных
5. **Категориальная точность** - сравнение только внутри одной категории

### 🔧 Технологии
- **Backend**: FastAPI + Python 3.9+
- **Frontend**: Vanilla JavaScript (без зависимостей)
- **База данных**: JSON файл (category_knowledge_base.json)
- **API интеграция**: Wildberries API, MPStat API

---

## 📋 Шаг 1: Подготовка данных

### 1.1 Создание базы знаний (локально)

```bash
# 1. Распакуйте архив
unzip WB_PRICE_OPTIMIZER_V2_COMPLETE.zip
cd WB_PRICE_OPTIMIZER_V2_COMPLETE

# 2. Установите зависимости
pip install pandas openpyxl tqdm

# 3. Положите Excel файлы в папку:
# - WB_Карнизы_24.11-07.12.25.xlsx
# - WB_Портьеры_24.11-07.12.25.xlsx
# - WB_РШ_24.11-07.12.25.xlsx

# 4. Запустите создание базы знаний
python load_excel_to_system.py
```

**Параметры для полной загрузки** (в `load_excel_to_system.py`):
```python
# Строка 180-182 - установите max_rows=None для всех файлов
df1 = load_excel_data(file1, max_rows=None)  # Было: max_rows=1000
df2 = load_excel_data(file2, max_rows=None)  # Было: max_rows=1000
df3 = load_excel_data(file3, max_rows=None)  # Было: max_rows=1000
```

**Результат**: Файл `category_knowledge_base.json` (размер зависит от объёма данных)

### 1.2 Проверка базы знаний

```python
import json
with open('category_knowledge_base.json', 'r', encoding='utf-8') as f:
    kb = json.load(f)
    print(f"Загружено товаров: {len(kb['products'])}")
    print(f"Групп конкурентов: {len(kb['groups'])}")
```

---

## 🔄 Шаг 2: Замена кода на GitHub

### 2.1 Структура репозитория

Ваш GitHub репозиторий должен выглядеть так:
```
your-repo/
├── main.py                          # ← ЗАМЕНИТЬ
├── requirements.txt                  # ← ЗАМЕНИТЬ
├── templates/
│   └── index.html                   # ← ЗАМЕНИТЬ
├── static/
│   ├── css/
│   │   └── styles.css               # ← ЗАМЕНИТЬ
│   └── js/
│       └── app.js                   # ← ЗАМЕНИТЬ
├── category_knowledge_base.json      # ← ЗАГРУЗИТЬ
└── README.md                        # (опционально)
```

### 2.2 Команды Git

```bash
# 1. Перейдите в локальную копию репозитория
cd /path/to/your/repo

# 2. Скопируйте новые файлы
cp /path/to/extracted/main.py .
cp /path/to/extracted/requirements.txt .
cp /path/to/extracted/templates/index.html templates/
cp /path/to/extracted/static/css/styles.css static/css/
cp /path/to/extracted/static/js/app.js static/js/
cp /path/to/extracted/category_knowledge_base.json .

# 3. Проверьте изменения
git status
git diff main.py  # Посмотрите изменения

# 4. Закоммитьте и запушьте
git add main.py requirements.txt templates/ static/ category_knowledge_base.json
git commit -m "Update to WB Price Optimizer V2.0 - Full system replacement"
git push origin main
```

---

## ☁️ Шаг 3: Развёртывание на Render

### 3.1 Настройка переменных окружения

В панели Render → Environment Variables:

```bash
# Обязательные
WB_API_KEY=ваш_ключ_wb_api
KNOWLEDGE_BASE_PATH=category_knowledge_base.json
PORT=10000

# Опциональные
MPSTAT_TOKEN=ваш_токен_mpstat  # Для сезонности
```

**Где взять API ключи:**
- **WB API**: https://seller.wildberries.ru/supplier-settings/access-to-api
- **MPStat**: https://mpstats.io/api (платная подписка)

### 3.2 Очистка кэша Render

**Критически важно!** Render может кешировать старые файлы.

#### Метод 1: Через Dashboard
1. Зайдите в ваш сервис на Render
2. Нажмите "Manual Deploy" → "Clear build cache & deploy"

#### Метод 2: Через терминал
```bash
# В настройках сервиса добавьте Build Command:
pip install --no-cache-dir -r requirements.txt
```

### 3.3 Проверка развёртывания

```bash
# 1. Проверьте health endpoint
curl https://your-app.onrender.com/health

# Ожидается:
{
  "status": "healthy",
  "kb_loaded": true,
  "products_count": 5425,
  "version": "2.0"
}

# 2. Проверьте статистику категорий
curl https://your-app.onrender.com/categories/stats

# 3. Проверьте фронтенд
curl -I https://your-app.onrender.com/static/css/styles.css
# Должен вернуть: HTTP/1.1 200 OK
```

---

## 🧪 Шаг 4: Тестирование

### 4.1 Локальное тестирование

```bash
# 1. Запустите backend локально
python main.py

# 2. Откройте браузер: http://localhost:8000
# 3. Введите артикул: 156631671
# 4. Нажмите "Анализировать"
```

### 4.2 Проверка функций

| Функция | Endpoint | Ожидаемый результат |
|---------|----------|---------------------|
| Главная страница | GET / | HTML интерфейс |
| Анализ товара | GET /analyze/full/156631671 | JSON с полным анализом |
| Excel экспорт | GET /export/excel | Скачивание .xlsx файла |
| Статистика | GET /categories/stats | JSON со статистикой |
| Добавление товара | POST /products/add | 200 OK |

### 4.3 Пример теста API

```python
import requests

# Тест анализа
response = requests.get('https://your-app.onrender.com/analyze/full/156631671')
data = response.json()

print(f"Оптимальная цена: {data['optimization']['optimal_price']}₽")
print(f"Эластичность: {data['elasticity']['elasticity']}")
print(f"ТОП конкурентов: {len(data['competitors'])}")
```

---

## 🔍 Шаг 5: Проверка корректности

### ✅ Чек-лист после развёртывания

- [ ] `category_knowledge_base.json` загружен и весит > 40 KB
- [ ] `/health` возвращает `kb_loaded: true`
- [ ] `/static/css/styles.css` возвращает CSS (не 404)
- [ ] `/static/js/app.js` возвращает JavaScript (не 404)
- [ ] Главная страница отображается корректно
- [ ] Анализ товара работает (введите артикул → кнопка "Анализировать")
- [ ] Excel экспорт скачивает файл
- [ ] В логах Render нет ошибок

### 🐛 Частые проблемы

#### Проблема 1: "KB not loaded"
**Решение**: 
```bash
# Проверьте наличие файла в репозитории
ls -lh category_knowledge_base.json

# Убедитесь, что переменная окружения правильная
echo $KNOWLEDGE_BASE_PATH  # Должно быть: category_knowledge_base.json
```

#### Проблема 2: 404 на static файлы
**Решение**:
```bash
# 1. Проверьте структуру папок
tree static/
static/
├── css/
│   └── styles.css
└── js/
    └── app.js

# 2. Очистите кэш Render (см. Шаг 3.2)
# 3. Перезапустите сервис
```

#### Проблема 3: WB API ошибка
**Решение**:
```bash
# Проверьте валидность ключа
curl -H "Authorization: $WB_API_KEY" https://statistics-api.wildberries.ru/api/v1/supplier/stocks

# Если ошибка - перегенерируйте ключ на seller.wildberries.ru
```

---

## 📊 Шаг 6: Использование приложения

### 6.1 Веб-интерфейс

1. Откройте: `https://your-app.onrender.com`
2. Введите артикул WB (nm_id)
3. Нажмите "🔍 Анализировать"
4. Просмотрите:
   - Оптимальную цену
   - Эластичность спроса
   - Сезонность
   - ТОП-20 конкурентов
   - Рекомендации

### 6.2 Excel экспорт

Нажмите "📊 Экспорт в Excel" для скачивания полного отчёта:

| Колонка | Описание |
|---------|----------|
| nm_id | Артикул WB |
| name | Название товара |
| category | Категория |
| current_price | Текущая цена |
| optimal_price | Оптимальная цена |
| price_change_pct | Изменение цены (%) |
| competitor_avg_price | Средняя цена конкурентов |
| elasticity | Эластичность спроса |
| seasonality_factor | Сезонный коэффициент |
| predicted_sales | Прогноз продаж (шт/мес) |
| predicted_revenue | Прогноз выручки (₽) |
| predicted_profit | Прогноз прибыли (₽) |
| top_competitor_price | Цена лучшего конкурента |
| recommendation | Рекомендация |
| group_id | ID группы конкурентов |

---

## 🔐 Безопасность

### Важно:
1. **НЕ** коммитьте `.env` файл с ключами API
2. Храните `WB_API_KEY` только в Render Environment Variables
3. Регулярно обновляйте `category_knowledge_base.json` (раз в неделю)

### .gitignore
```
.env
*.pyc
__pycache__/
*.log
venv/
.DS_Store
```

---

## 📞 Поддержка

### Логи Render
```bash
# В панели Render → Logs
# Ищите ошибки при старте приложения
```

### Проверка работоспособности
```bash
# Каждое утро проверяйте:
curl https://your-app.onrender.com/health
```

---

## 🎉 Готово!

Ваше приложение WB Price Optimizer V2.0 готово к использованию!

**URL**: https://your-app.onrender.com

**Возможности**:
- ✅ Анализ эластичности спроса
- ✅ ТОП-20 конкурентов по продажам
- ✅ Учёт сезонности (MPStat/WB)
- ✅ Категориальная точность
- ✅ Excel экспорт с полным отчётом
- ✅ Прогноз продаж и прибыли

**Следующие шаги**:
1. Загрузите полные Excel файлы (155,793 товара)
2. Настройте автоматическое обновление базы знаний (cron)
3. Интегрируйте с вашей CRM/ERP системой
