# 🎯 WB Price Optimizer v2.0 - ОКОНЧАТЕЛЬНАЯ ВЕРСИЯ

## 🚀 Что это?

Полноценная система оптимизации цен для Wildberries с:

1. ✅ **Анализом эластичности спроса** через API WB
2. ✅ **Топ конкурентами** (только из той же категории)
3. ✅ **Учётом сезонности** (WB + MPStat API)
4. ✅ **Выгрузкой в Excel** с детальными рекомендациями
5. ✅ **Базой знаний категорий** из ваших Excel файлов

---

## 📦 Структура проекта

```
wb-price-optimizer/
├── main.py                           ← Основной файл (замена старого кода)
├── requirements.txt                  ← Зависимости
├── category_knowledge_base.json      ← База знаний (создаётся отдельно)
├── load_excel_to_system.py          ← Скрипт загрузки данных из Excel
├── static/                           ← Фронтенд (опционально)
│   ├── index.html
│   ├── css/styles.css
│   └── js/app.js
└── .env                              ← Конфигурация
```

---

## 🔧 Установка

### **Шаг 1: Установка зависимостей**

```bash
pip install -r requirements.txt
```

---

### **Шаг 2: Создание базы знаний**

Поместите ваши Excel файлы в папку с проектом:
- `WB_Карнизы_24.11-07.12.25.xlsx`
- `WB_Портьеры_24.11-07.12.xlsx`
- `WB_РШ_24.11.25-07.12.25.xlsx`

Запустите:

```bash
python load_excel_to_system.py
```

Результат: Файл `category_knowledge_base.json` (база знаний)

---

### **Шаг 3: Настройка API ключей**

Создайте файл `.env`:

```env
# API Wildberries (обязательно)
WB_API_KEY=your_wildberries_api_key_here

# API MPStat (опционально, для сезонности)
MPSTAT_TOKEN=your_mpstat_token_here

# База знаний
KNOWLEDGE_BASE_PATH=category_knowledge_base.json

# Порт
PORT=8000
```

**Как получить WB API ключ:**
1. Личный кабинет Wildberries
2. Настройки → API → Создать токен
3. Права: Чтение статистики продаж

**Как получить MPStat токен:**
1. https://mpstats.io
2. Личный кабинет → API → Создать токен

---

### **Шаг 4: Запуск**

```bash
python main.py
```

Приложение запустится на `http://localhost:8000`

---

## 🔍 API Endpoints

### **1. Проверка здоровья**

```http
GET /health
```

**Ответ:**
```json
{
  "status": "ok",
  "wb_api": "configured",
  "mpstat_api": "configured",
  "knowledge_base": {
    "loaded": true,
    "products": 5425
  }
}
```

---

### **2. Полный анализ товара**

```http
GET /analyze/full/156631671?goal=profit&history_days=30
```

**Параметры:**
- `nm_id` — артикул товара
- `goal` — `profit` | `revenue` | `balanced`
- `history_days` — период анализа (7-90)

**Ответ:**
```json
{
  "nm_id": 156631671,
  "category": "блэкаут",
  "current_price": 1544.00,
  
  "demand_analysis": {
    "elasticity": -1.81,
    "interpretation": "Умеренный",
    "best_sales_day": {
      "sales": 62,
      "price": 1400.00
    }
  },
  
  "competitor_analysis": {
    "top_sellers": [...],
    "category_note": "Только категория 'блэкаут'"
  },
  
  "seasonality": {
    "seasonality_index": 1.15,
    "interpretation": "📈 Повышенный спрос",
    "source": "WB API"
  },
  
  "price_optimization": {
    "optimal_price": 1620.50,
    "base_price": 1575.00,
    "seasonality_adjustment": "Цена повышена на 5%"
  },
  
  "recommendation": "⬆️ Повысить на 4.9% до 1620₽ | 🏆 Топ продавец: 1708₽"
}
```

---

### **3. Выгрузка в Excel**

```http
GET /export/excel?nm_ids=156631671,159787876,306083349&goal=profit
```

**Параметры:**
- `nm_ids` — артикулы через запятую
- `goal` — цель оптимизации

**Результат:** Скачивается файл `price_recommendations_YYYYMMDD_HHMMSS.xlsx`

**Колонки Excel:**
1. Артикул
2. Название
3. Категория
4. Текущая цена
5. Оптимальная цена (эластичность)
6. Лучшие наши продажи
7. Цена при лучших продажах
8. Цена топ конкурента
9. Продажи топ конкурента
10. Цена с макс выручкой
11. Выручка конкурента
12. Индекс сезонности
13. Сезон
14. Эластичность
15. Рекомендация

---

### **4. Статистика категорий**

```http
GET /categories/stats
```

**Ответ:**
```json
{
  "statistics": {
    "Карнизы": {"алюминиевый": 1500, "стандарт": 890},
    "Портьеры": {"блэкаут": 700, "канвас": 550}
  },
  "total_products": 5425,
  "total_groups": 1476
}
```

---

### **5. Добавить товар**

```http
POST /products/add
Content-Type: application/json

{
  "nm_id": 156631671,
  "name": "Шторы блэкаут 2 шт",
  "category": "блэкаут",
  "current_price": 1544.00,
  "cost": 1080.00
}
```

---

## 📊 Пример использования

### **Через curl:**

```bash
# Полный анализ
curl "http://localhost:8000/analyze/full/156631671?goal=profit"

# Выгрузка в Excel
curl -o prices.xlsx "http://localhost:8000/export/excel?nm_ids=156631671,159787876&goal=profit"
```

---

### **Через Python:**

```python
import requests

# Анализ товара
response = requests.get(
    "http://localhost:8000/analyze/full/156631671",
    params={"goal": "profit", "history_days": 30}
)
data = response.json()

print(f"Оптимальная цена: {data['price_optimization']['optimal_price']}₽")
print(f"Рекомендация: {data['recommendation']}")

# Выгрузка в Excel
nm_ids = [156631671, 159787876, 306083349]
response = requests.get(
    "http://localhost:8000/export/excel",
    params={"nm_ids": ','.join(map(str, nm_ids)), "goal": "profit"}
)

with open('recommendations.xlsx', 'wb') as f:
    f.write(response.content)
```

---

## 🔐 Настройка на Render

### **1. Подготовка репозитория**

```
git add main.py requirements.txt category_knowledge_base.json
git commit -m "Update to v2.0"
git push origin main
```

---

### **2. Настройка Render**

1. Dashboard → Web Service → Connect GitHub
2. **Build Command:** `pip install -r requirements.txt`
3. **Start Command:** `python main.py`
4. **Environment Variables:**
   ```
   WB_API_KEY=your_key_here
   MPSTAT_TOKEN=your_token_here (опционально)
   KNOWLEDGE_BASE_PATH=category_knowledge_base.json
   PORT=8000
   ```

---

### **3. Проверка**

```bash
curl https://your-app.onrender.com/health
```

---

## 📈 Как работает система

### **1. Анализ эластичности спроса**

```
История продаж WB за 30 дней:
День 1-10: Цена 1400₽ → 62 продажи/день
День 11-20: Цена 1544₽ → 50 продаж/день
День 21-30: Цена 1700₽ → 38 продаж/день

Эластичность: E = -1.81
→ Умеренная чувствительность к цене
```

---

### **2. Топ конкуренты (только из той же категории)**

```
Категория: блэкаут
ID склейки: 149019446

ТОП-3:
1. SKU 159787876 — 1708₽ — 120 продаж/нед
2. SKU 306083349 — 1488₽ — 95 продаж/нед
3. SKU 499621427 — 1430₽ — 87 продаж/нед

Взвешенная средняя: 1575₽
```

---

### **3. Учёт сезонности**

```
Индекс сезонности: 1.15
Интерпретация: 📈 Повышенный спрос

→ Можем повысить цену на 5%
```

---

### **4. Оптимальная цена**

```
Формула: P* = Cost / (1 + 1/E)
P* = 1080 / (1 + 1/(-1.81))
P* = 1080 / 0.45 = 2400₽

Ограничения:
- Не выше топ конкурента × 1.1
- Не ниже себестоимости × 1.2

Корректировка на сезонность: +5%

Финальная рекомендация: 1620₽
```

---

## 🎯 Ключевые отличия от старой версии

| Аспект | Старая версия | Новая версия v2.0 |
|--------|---------------|-------------------|
| **Эластичность спроса** | ❌ Нет | ✅ Через WB API |
| **Топ конкуренты** | ⚠️ Все из группы | ✅ Только топ продавцы |
| **Категории** | ⚠️ Смешивает блэкаут/однотон | ✅ Строгая фильтрация |
| **Сезонность** | ❌ Нет | ✅ WB + MPStat API |
| **Excel выгрузка** | ❌ Нет | ✅ 15 колонок с анализом |
| **База знаний** | ❌ Нет | ✅ 155,793 товара |
| **Формула цены** | ⚠️ Простая | ✅ С эластичностью |
| **Прогноз** | ❌ Нет | ✅ Продажи/выручка |

---

## 🛠️ Устранение проблем

### ❌ "База знаний не найдена"

```bash
python load_excel_to_system.py
```

---

### ❌ "WB API не настроен"

Проверьте `.env`:
```env
WB_API_KEY=your_key_here
```

Приложение будет работать с тестовыми данными, но рекомендуем настроить API.

---

### ❌ "Товар не найден в базе знаний"

Убедитесь, что товар есть в ваших Excel файлах и база знаний создана.

---

## ✅ Итого

### **Что готово:**

1. ✅ Полная замена старого кода
2. ✅ Интеграция с WB API
3. ✅ Анализ эластичности спроса
4. ✅ Топ конкуренты по категориям
5. ✅ Учёт сезонности
6. ✅ Выгрузка в Excel
7. ✅ База знаний из Excel файлов

### **Следующие шаги:**

1. Замените `main.py` в вашем репозитории
2. Загрузите `requirements.txt`
3. Создайте базу знаний из Excel
4. Настройте API ключи
5. Деплой на Render

---

**🚀 Готово к production!**
