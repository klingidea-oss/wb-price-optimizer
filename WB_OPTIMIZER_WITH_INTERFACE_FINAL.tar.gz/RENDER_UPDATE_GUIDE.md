# 🚀 Инструкция по обновлению приложения на Render.com

## 🎯 Проблема
Приложение на https://wb-price-optimizer.onrender.com/ работает, но показывает только JSON вместо красивого веб-интерфейса.

## ✅ Решение
Нужно обновить код на Render, добавив папки `templates/` и `static/` с интерфейсом.

---

## 📦 Вариант 1: Через GitHub (РЕКОМЕНДУЕТСЯ)

### Шаг 1: Загрузите файлы в GitHub репозиторий

Ваш текущий репозиторий на Render подключен к GitHub. Нужно добавить/обновить следующие файлы:

```
wb-price-optimizer/
├── main.py                          # ✅ ОБНОВИТЬ (добавлен HTML route)
├── requirements.txt                 # ✅ ОБНОВИТЬ (добавлен jinja2)
├── category_knowledge_base.json     # ✅ Оставить как есть
├── templates/                       # ⚠️ ДОБАВИТЬ ПАПКУ
│   └── index.html                   # HTML интерфейс
├── static/                          # ⚠️ ДОБАВИТЬ ПАПКУ
│   ├── css/
│   │   └── styles.css              # Стили
│   └── js/
│       └── app.js                  # JavaScript логика
└── load_excel_to_system.py         # (опционально)
```

### Шаг 2: Команды для загрузки (если используете Git)

```bash
# Скачайте обновленные файлы с этого компьютера
# Затем в вашем локальном репозитории:

git add main.py requirements.txt templates/ static/
git commit -m "Add web interface with templates and static files"
git push origin main
```

### Шаг 3: Render автоматически задеплоит

- Render обнаружит изменения в GitHub
- Автоматически пересоберет приложение (2-3 минуты)
- После деплоя откройте: https://wb-price-optimizer.onrender.com/
- Вы увидите красивый интерфейс! 🎉

---

## 📂 Вариант 2: Ручное обновление через Render Shell

Если у вас нет доступа к GitHub репозиторию:

### Шаг 1: Откройте Render Shell

1. Зайдите на https://dashboard.render.com/
2. Выберите ваш сервис `wb-price-optimizer`
3. Нажмите **"Shell"** в верхнем меню

### Шаг 2: Загрузите файлы

В Shell выполните:

```bash
# Создайте папки
mkdir -p templates static/css static/js

# Загрузите файлы (используйте curl или вставьте содержимое вручную)
# Для каждого файла создайте его через nano/vi и вставьте содержимое
```

**Проблема этого метода:** При следующем деплое файлы пропадут.

---

## 🔧 Вариант 3: Полный редеплой (если нет GitHub)

### Шаг 1: Скачайте готовый архив

Скачайте `WB_PRICE_OPTIMIZER_COMPLETE.zip` с этого компьютера.

### Шаг 2: Создайте новый GitHub репозиторий

1. Зайдите на https://github.com/new
2. Назовите: `wb-price-optimizer`
3. Public или Private
4. Create repository

### Шаг 3: Загрузите все файлы

- Распакуйте архив
- Через веб-интерфейс GitHub: "Add file" → "Upload files"
- Загрузите ВСЕ файлы и папки

### Шаг 4: Переподключите Render

В настройках вашего Render сервиса:

1. Settings → Repository
2. Disconnect старый репозиторий
3. Connect новый репозиторий
4. Render автоматически задеплоит

---

## ⚙️ Проверка после обновления

После успешного деплоя:

### 1. Откройте главную страницу
```
https://wb-price-optimizer.onrender.com/
```

**Должны увидеть:**
- 🎯 Заголовок "WB Price Optimizer V2.0"
- 📊 Три карточки со статистикой (товары, категории, группы)
- 🔍 Поле для ввода артикула
- 📊 Кнопку "Экспорт в Excel"

### 2. Проверьте API
```
https://wb-price-optimizer.onrender.com/api
```

Должен вернуть JSON с информацией о системе (как раньше).

### 3. Протестируйте функционал

- Введите любой артикул WB (например: `123456789`)
- Нажмите "🔍 Анализировать"
- Должен появиться результат анализа

---

## 🐛 Решение проблем

### Ошибка: "Internal Server Error"

**Причина:** Не найдены templates/static

**Решение:**
1. Проверьте структуру папок в репозитории
2. Убедитесь, что `templates/index.html` существует
3. Проверьте логи на Render (Logs → View logs)

### Интерфейс не стилизован

**Причина:** Не загружаются CSS/JS файлы

**Решение:**
1. Откройте консоль браузера (F12)
2. Проверьте ошибки в Console
3. Убедитесь, что файлы в `static/css/` и `static/js/` загружены

### API работает, интерфейс нет

**Причина:** Route "/" не обновлен

**Решение:**
1. Проверьте, что `main.py` обновлен
2. В коде должен быть:
```python
from fastapi.templating import Jinja2Templates
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
```

---

## 📊 Что изменилось

### В `main.py`:

**Было:**
```python
@app.get("/")
async def root():
    return {"status": "healthy", ...}  # JSON ответ
```

**Стало:**
```python
@app.get("/", response_class=HTMLResponse)
async def root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/api")  # JSON перенесен сюда
async def api_info():
    return {"status": "healthy", ...}
```

### В `requirements.txt`:

**Добавлено:**
```
jinja2==3.1.2
```

### Новые файлы:

```
+ templates/index.html    (4 KB)
+ static/css/styles.css   (7 KB)
+ static/js/app.js        (14 KB)
```

---

## 🎉 Результат после обновления

### До:
```
https://wb-price-optimizer.onrender.com/
→ {"status":"healthy","service":"WB Price Optimizer v2.0"...}
```

### После:
```
https://wb-price-optimizer.onrender.com/
→ 🎯 Красивый веб-интерфейс с графиками и формами
```

---

## 💡 Рекомендации

1. **Используйте GitHub для деплоя** - это самый надежный способ
2. **Проверяйте логи Render** при возникновении ошибок
3. **Тестируйте локально** перед деплоем:
   ```bash
   uvicorn main:app --reload
   # Откройте: http://localhost:8000/
   ```

---

## 📞 Помощь

Если что-то не работает:

1. **Проверьте логи:** Dashboard → Your Service → Logs
2. **Структура файлов:** Убедитесь, что все папки на месте
3. **Build успешен:** Смотрите статус деплоя в Render

---

**Готово!** После обновления ваше приложение будет иметь полноценный веб-интерфейс 🚀
