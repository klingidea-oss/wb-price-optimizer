#!/usr/bin/env python3
"""
Полная загрузка данных из Excel в систему с созданием базы знаний категорий
"""

import pandas as pd
import json
from collections import defaultdict

print("="*80)
print("🚀 ПОЛНАЯ ЗАГРУЗКА ДАННЫХ ИЗ EXCEL")
print("="*80)

# === КОНФИГУРАЦИЯ ===
FILES = {
    'Карнизы': {
        'path': 'WB_Карнизы_24.11-07.12.25.xlsx',
        'category_col': 'Тип карниза/аналог',
        'max_rows': None  # Загружаем всё
    },
    'Портьеры': {
        'path': 'WB_Портьеры_24.11-07.12.xlsx',
        'category_col': 'Категория',
        'max_rows': None
    },
    'РШ': {
        'path': 'WB_РШ_24.11.25-07.12.25.xlsx',
        'category_col': 'Категория',
        'max_rows': None
    }
}

# === ИЗВЛЕКАЕМ ДАННЫЕ ===

category_mapping = {}
product_database = {}

for product_type, config in FILES.items():
    print(f"\n{'='*70}")
    print(f"📂 {product_type}")
    print('='*70)
    
    try:
        df = pd.read_excel(config['path'], sheet_name=0, nrows=config['max_rows'])
        print(f"✅ Загружено {len(df)} строк")
    except FileNotFoundError:
        print(f"❌ Файл не найден: {config['path']}")
        continue
    except Exception as e:
        print(f"❌ Ошибка чтения: {e}")
        continue
    
    # Проверяем наличие нужных колонок
    required_cols = ['SKU', 'Название', 'Цена']
    optional_cols = ['ID склейки', config['category_col'], 'Бренд', 'Отзывы', 'Размер']
    
    available_cols = [col for col in required_cols + optional_cols if col in df.columns]
    
    if 'ID склейки' not in available_cols:
        print(f"⚠️  'ID склейки' не найдена - пропускаем файл")
        continue
    
    # Обрабатываем данные
    groups = defaultdict(lambda: {'products': [], 'categories': set()})
    valid_rows = 0
    
    for idx, row in df.iterrows():
        # Пропускаем строки без ключевых данных
        if pd.isna(row.get('SKU')) or pd.isna(row.get('Цена')) or pd.isna(row.get('ID склейки')):
            continue
        
        try:
            nm_id = int(row['SKU'])
            group_id = int(row['ID склейки'])
            price = float(row['Цена'])
            name = str(row['Название'])[:200]
            
            # Категория
            category = 'не указана'
            if config['category_col'] in df.columns and not pd.isna(row.get(config['category_col'])):
                category = str(row[config['category_col']]).strip().lower()
            
            # Дополнительные поля
            brand = str(row.get('Бренд', '')) if 'Бренд' in df.columns else ''
            reviews = int(row.get('Отзывы', 0)) if 'Отзывы' in df.columns else 0
            size = str(row.get('Размер', '')) if 'Размер' in df.columns else ''
            
            # Сохраняем в базу товаров
            product_database[nm_id] = {
                'nm_id': nm_id,
                'name': name,
                'product_type': product_type,
                'category': category,
                'group_id': group_id,
                'price': price,
                'brand': brand,
                'reviews': reviews,
                'size': size
            }
            
            # Добавляем в группу
            groups[group_id]['products'].append(nm_id)
            groups[group_id]['categories'].add(category)
            
            valid_rows += 1
            
        except (ValueError, TypeError) as e:
            continue
    
    # Сохраняем маппинг категорий
    category_mapping[product_type] = {}
    for group_id, data in groups.items():
        # Определяем основную категорию группы (самая частая)
        if data['categories']:
            category_counts = {}
            for nm_id in data['products']:
                cat = product_database[nm_id]['category']
                category_counts[cat] = category_counts.get(cat, 0) + 1
            main_category = max(category_counts.items(), key=lambda x: x[1])[0]
        else:
            main_category = 'не указана'
        
        category_mapping[product_type][group_id] = {
            'main_category': main_category,
            'all_categories': list(data['categories']),
            'product_count': len(data['products'])
        }
    
    print(f"   ✅ Обработано товаров: {valid_rows}")
    print(f"   📦 Групп конкурентов: {len(groups)}")
    
    # ТОП-5 категорий
    category_counts = defaultdict(int)
    for nm_id, data in product_database.items():
        if data['product_type'] == product_type:
            category_counts[data['category']] += 1
    
    print(f"\n   🏆 ТОП-5 категорий:")
    for cat, count in sorted(category_counts.items(), key=lambda x: x[1], reverse=True)[:5]:
        print(f"      • {cat}: {count} товаров")

# === СОХРАНЯЕМ РЕЗУЛЬТАТЫ ===

print(f"\n{'='*80}")
print(f"💾 СОХРАНЕНИЕ РЕЗУЛЬТАТОВ")
print('='*80)

knowledge_base = {
    'category_mapping': category_mapping,
    'product_database': {str(k): v for k, v in product_database.items()},
    'statistics': {
        'total_products': len(product_database),
        'total_groups': sum(len(groups) for groups in category_mapping.values()),
        'product_types': list(FILES.keys()),
        'categories_by_type': {
            pt: len(set(p['category'] for p in product_database.values() if p['product_type'] == pt))
            for pt in FILES.keys()
        }
    }
}

# Сохраняем базу знаний
with open('category_knowledge_base.json', 'w', encoding='utf-8') as f:
    json.dump(knowledge_base, f, ensure_ascii=False, indent=2)

print(f"✅ Сохранено: category_knowledge_base.json")

# Сохраняем CSV для анализа
df_export = pd.DataFrame([
    {
        'nm_id': data['nm_id'],
        'name': data['name'],
        'product_type': data['product_type'],
        'category': data['category'],
        'group_id': data['group_id'],
        'price': data['price'],
        'brand': data['brand']
    }
    for data in product_database.values()
])
df_export.to_csv('product_database.csv', index=False, encoding='utf-8-sig')
print(f"✅ Сохранено: product_database.csv")

# Итоговая статистика
print(f"\n{'='*80}")
print(f"📊 ИТОГОВАЯ СТАТИСТИКА")
print('='*80)
print(f"   • Всего товаров: {knowledge_base['statistics']['total_products']}")
print(f"   • Групп конкурентов: {knowledge_base['statistics']['total_groups']}")
print(f"   • Типов товаров: {len(knowledge_base['statistics']['product_types'])}")
print(f"\n   📦 По типам:")
for pt, cat_count in knowledge_base['statistics']['categories_by_type'].items():
    product_count = len([p for p in product_database.values() if p['product_type'] == pt])
    print(f"      • {pt}: {product_count} товаров, {cat_count} категорий")

print(f"\n{'='*80}")
print(f"🎉 ГОТОВО!")
print('='*80)
print(f"\n📁 Созданные файлы:")
print(f"   1. category_knowledge_base.json - база знаний для backend")
print(f"   2. product_database.csv - все товары в CSV")
print(f"\n🚀 Следующий шаг:")
print(f"   Запустите backend: python wb_backend_with_categories.py")
